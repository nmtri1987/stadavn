﻿Param($SiteUrl, $UserName, $Password)

#Set-ExecutionPolicy unrestricted
if($SiteUrl -eq $null){
    $SiteUrl = "https://bitisvn.sharepoint.com/sites/BitopiaPortalUAT"
}
if($UserName -eq $null){
    $UserName = "admin@bitisvn.onmicrosoft.com"
}
if($Password -eq $null)
{
    $Password = [string] 'B!t!sP@$$w0rd'
}

#Get current path
$currentDirectory = split-path -parent $MyInvocation.MyCommand.Definition
$logFilePath = $currentDirectory+"\PowerShellLogs\ImportEmployee.txt"

#Add DLL
Add-Type -Path ($currentDirectory + "\DLL\Microsoft.SharePoint.Client.dll") 
Add-Type -Path ($currentDirectory + "\DLL\Microsoft.SharePoint.Client.Runtime.dll")

# Generate ClientContext function
function Get-SPOContext([string]$url,[string]$userName,[string]$password)
{
   $context = New-Object Microsoft.SharePoint.Client.ClientContext($url)
   $securePassword = $password | ConvertTo-SecureString -AsPlainText -Force
   $credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($userName, $securePassword)
   $context.Credentials = $credentials
   return $context;
}

#----Functions------------------------------------------------------------------------
#Position
function CheckPositionExist($context, $title)
{
    $camlString2 = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+$title+"</Value></Eq></Where></Query></View>";
    $listItemResults2 = Get-DataByCAML $context "Position" $camlString2
	if($listItemResults2 -ne $null -and $listItemResults2.Count -gt 0)
	{
        $item2 = $listItemResults2 | Select-Object -first 1
        return $item2.ID;
	}
    else
	{
		return 0;
	}
}

function InsertPosition($context, $positionList, $title)
{
    if($context -ne $null -AND $positionList -ne $null -AND $title -ne "")
    {
        $positionItemCreateInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation 
        $positionListItem = $positionList.addItem($positionItemCreateInfo) 
        $positionListItem.set_item('Title', $title)
        $positionListItem.update();
        $context.Load($positionListItem)
        $context.ExecuteQuery()
        Write-Host "Created position: " $title
        return $positionListItem.ID
     }
     else
     {
        return 0;
     }
}
#End Position

#Department
function CheckDepartmentExist($context, $title)
{
    $camlString3 = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+$title+"</Value></Eq></Where></Query></View>";
    $listItemResults3 = Get-DataByCAML $context "Department" $camlString3
	if($listItemResults3 -ne $null -and $listItemResults3.Count -gt 0)
	{
        $item3 = $listItemResults3 | Select-Object -first 1
        return $item3.ID;
	}
    else
	{
		return 0;
	}
}

function InsertDepartment($context, $departmentList, $title)
{
    if($context -ne $null -AND $departmentList -ne $null -AND $title -ne "")
    {
        $departmentItemCreateInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation 
        $departmentListItem = $departmentList.addItem($departmentItemCreateInfo) 
        $departmentListItem.set_item('Title', $title)
        $departmentListItem.update();
        $context.Load($departmentListItem)
        $context.ExecuteQuery()
        $mes = "Created department: "+$title
        Write-Host $mes
        Log-File $mes
        return $departmentListItem.ID
    }
    else
    {
        return 0;
    }
}

#End Department

#Company
function GetCompany($context, $company)
{
    $camlString4 = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+$company+"</Value></Eq></Where></Query></View>";
    $listItemResults4 = Get-DataByCAML $context "Company" $camlString4
	if($listItemResults4 -ne $null -and $listItemResults4.Count -gt 0)
	{		
        $item4 = $listItemResults4 | Select-Object -first 1
        return $item4.ID;
	}
    else
	{
		return 0;
	}
}
#End Company
#----End Functions-------------------------------------------------------------------

function Proccess-Position($context, $title){
    
    $positionList = $context.Web.Lists.GetByTitle("Position")
    if($context -ne $null -AND $positionList -ne $null)
    {
      $existedPositionId = CheckPositionExist $context $title
      if($existedPositionId -gt 0)
      {
       return  $existedPositionId;
      }
      else
      {
        return InsertPosition $context $positionList $title
      }
    }
    else
    {
        return 0;
    }
}

function Proccess-Department($context, $title){
    $departmentList = $context.Web.Lists.GetByTitle("Department")
    if($context -ne $null -AND $departmentList -ne $null)
    {
      $existedDepartmentId = CheckDepartmentExist $context $title
      if($existedDepartmentId -gt 0)
      {
       return  $existedDepartmentId;
      }
      else
      {
        return InsertDepartment $context $departmentList $title
      }
    }
    else
    {
        return 0;
    }
}


function CheckEmployeeIDExist($context, $employeeID)
{
	$camlString1 = "<View><Query><Where><Eq> <FieldRef Name='EmployeeID' /><Value Type='Text'>"+$employeeID+"</Value></Eq></Where></Query></View>";
	$listItemResults = Get-DataByCAML $context "Employee" $camlString1
	if($listItemResults -ne $null -and $listItemResults.Count -gt 0)
	{
		$item = $listItemResults | Select-Object -first 1
        return $item.ID;
        
	}else
	{
		return 0;
	}
}

function InsertEmployeeItem($context, $spEmployeelist, $itemData)
{
	try
	{
		$web = $context.Web;   
		$itemCreateInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation 
        $empSPlistItem = $spEmployeelist.addItem($itemCreateInfo) 
        $empSPlistItem.set_item("Title", "Nhân viên " + $itemData.FullName);
        $empSPlistItem.update();
		$empSPlistItem.set_item("FirstName", $itemData.FirstName);
        $empSPlistItem.update();
		$empSPlistItem.set_item('LastName', $itemData.LastName);
        $empSPlistItem.update();
		$empSPlistItem.set_item('FullName', $itemData.FullName);
        $empSPlistItem.update();
		$empSPlistItem.set_item('EmployeeID', $itemData.EmployeeID);
        $empSPlistItem.update();
        $positionId = Proccess-Position $context $itemData.Position;
        $empSPlistItem.set_item('Position', $positionId);
        $empSPlistItem.update();    
        $departmentId = Proccess-Department $context $itemData.Department
        $empSPlistItem.set_item('Department', $departmentId)
        $empSPlistItem.update();
        $empSPlistItem.set_item('IsActive', "True")
        $empSPlistItem.update();
		$empSPlistItem.set_item('Level', $itemData.Level)
        $empSPlistItem.update();
		$accountEmail = ($itemData.Account + "").Trim()

		if($accountEmail -ne $null -and $accountEmail -ne "")
		{
			$user = $web.EnsureUser($accountEmail)
			if($user -ne $null)
			{
				$empSPlistItem.set_item('Account',$user)
			}
		}
        $empSPlistItem.update();
        $empSPlistItem.set_item('JoinedDate', $itemData.JoinedDate)
        $empSPlistItem.update();
        $companyId = GetCompany $context $itemData.Company;
        $empSPlistItem.set_item('Company', $companyId)
        $empSPlistItem.update();
        $empSPlistItem.set_item('StandardAnnualLeave', [float]$itemData.StandardAnnualLeave)
        $empSPlistItem.update();
        $context.Load($empSPlistItem); 
        $context.ExecuteQuery() 
        $mes = "Successfully inserted: " + $itemData.FullName
		Write-Host $mes -ForegroundColor Green
        Log-File $mes
	}
	catch
    {
        $message = "Error - insert employee  $itemData.FullName error: $_"
        Write-Host $message -ForegroundColor Red
        Log-File $message
    }
}

function UpdateEmployeeItem($context, $spEmployeelist, $itemId, $itemData)
{
	try
    {
        $web = $context.Web;
        $empSPlistItem = $spEmployeelist.GetItemById($itemId)  
        if($empSPlistItem -ne $null)
        {
            $empSPlistItem["Title"] = "Nhân viên " + $itemData.FullName;
            $empSPlistItem.Update();
            $empSPlistItem["FirstName"] = $itemData.FirstName;
            $empSPlistItem.Update();
            $empSPlistItem["LastName"] = $itemData.LastName;
            $empSPlistItem.Update();
            $empSPlistItem["FullName"] = $itemData.FullName;
            $empSPlistItem.Update();
            #$empSPlistItem["EmployeeID"] = $listItem.EmployeeID;
            #$empSPlistItem.Update();
             $positionId = Proccess-Position $context $itemData.Position;
            $empSPlistItem["Position"] = $positionId;
            $empSPlistItem.update();    
            $departmentId = Proccess-Department $context $itemData.Department
            $empSPlistItem["Department"] =  $departmentId;
            $empSPlistItem.update();
            $accountEmail = ($itemData.Account + "").Trim()

		    if($accountEmail -ne $null -and $accountEmail -ne "")
		    {
			    $user = $web.EnsureUser($accountEmail)
			    if($user -ne $null)
			    {
				    $empSPlistItem["Account"] = $user;
			    }
		    }
            $empSPlistItem.update();
            $empSPlistItem["JoinedDate"] =  $itemData.JoinedDate
            $empSPlistItem.update();
            $companyId = GetCompany $context $itemData.Company;
            $empSPlistItem["Company"] =  $companyId;
            $empSPlistItem.update();
            $empSPlistItem["StandardAnnualLeave"] = [float]$itemData.StandardAnnualLeave;
            $empSPlistItem.update();
			$empSPlistItem["Level"] =  $itemData.Level
            $empSPlistItem.update();
            $context.load($empSPlistItem);  
            $context.executeQuery()  
            $mes = "Successfully updated: " + $itemData.FullName
		    Write-Host $mes -ForegroundColor Green
            Log-File $mes
        }
	}
	catch
    {
        $message = "Error- Update employee  $itemData.FullName error: $_"
        Write-Host $message -ForegroundColor Red
        Log-File $message
    }
}

function Log-File($mesage)
{
    $currentDate = Get-Date
    "$currentDate : $mesage" |Out-File $logFilePath -Append;   
}

function Get-DataByCAML($context, $listTitle, $camlString)
{
	$listItems = $null;
	if($context -ne $null -and $listTitle -ne "" -and $camlString -ne "")
	{
		$list = $context.Web.Lists.GetByTitle($listTitle)
        $context.Load($list)
		if($list -ne $null)
		{
			$cquery = New-Object Microsoft.SharePoint.Client.CamlQuery
			$cquery.ViewXml=$camlString    
			$listItems = $list.GetItems($cquery)
			$context.load($listItems)    
			$context.executeQuery()
		}
	}
	return $listItems;
}


function ImportData($context)
{
    try{
        $listTitle = "Employee"
        $employeeSPList = $context.Web.Lists.GetByTitle($listTitle)
        $context.Load($employeeSPList)
        $context.ExecuteQuery() #if has error, change DNS to 8.8.8.8 :D
    
        $filePath = $currentDirectory + "\CSVFile\EmployeeData.csv"
    
        $employeeCsvFilePath = get-item $filePath
	    Write-Host "Path of file :: " $employeeCsvFilePath
        Write-Host "Reading " $employeeCsvFilePath " file" -ForegroundColor Green
	    if($employeeSPList -ne $null)
	    {
            $index=1
		    foreach($itemData in Import-Csv $employeeCsvFilePath)
		    {
                Log-File ("ROW " + $index)
			    $existId =  CheckEmployeeIDExist $context $itemData.EmployeeID
			    if($existId -eq 0)
			    {
				    Write-Host "Insert " $itemData.FullName
				    InsertEmployeeItem $context $employeeSPList $itemData
			    }
			    else
			    {
				    Write-Host "Update "  $itemData.FullName
				    UpdateEmployeeItem $context $employeeSPList $existId $itemData
			    }
            $index=$index+1
		    }
	    }
	    else
	    {
		    Write-Host "Error - Can not find employee list" -ForegroundColor Red
            Log-File "Error - Can not find employee list"
            
	    }
    }
    catch
    {
        $message = "Error- import employee error: $_"
        Write-Host $message -ForegroundColor Red
        Log-File $message
    }
}

function Main-ImportEmployee
{
	$context = Get-SPOContext $SiteUrl $UserName $Password
    if($context -ne $null)
    {
		ImportData $context
        $context.Dispose()
    }
}

Write-Host " "
Write-Host "START - IMPORT EMPLOYEE" -ForegroundColor Yellow
Main-ImportEmployee
Write-Host "END - IMPORT EMPLOYEE" -ForegroundColor Yellow

